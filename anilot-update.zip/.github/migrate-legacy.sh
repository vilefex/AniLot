#!/bin/bash
# Одноразовая миграция со старого имени проекта на AniLot.
# Скрипт распаковывается из anilot-update.zip; workflow удаляет его после выполнения.
# Можно перезапускать вручную: все шаги идемпотентны.
set -e

merge_into() {
  # $1 — старый каталог, $2 — новый каталог.
  # Файлы из git приоритетнее: дописываем только недостающие.
  (cd "$1" && find . \( -type f -o -type l \) -print0) | while IFS= read -r -d '' f; do
    if [ ! -e "$2/$f" ] && [ ! -L "$2/$f" ]; then
      mkdir -p "$2/$(dirname "$f")"
      cp -a "$1/$f" "$2/$f"
    fi
  done
  rm -rf "$1"
}

mkdir -p AniLot AniLot.xcodeproj
[ -d AniAnglia ] && merge_into AniAnglia AniLot
[ -d AniAnglia.xcodeproj ] && merge_into AniAnglia.xcodeproj AniLot.xcodeproj

# pbxproj ссылается на AniLot/AniLot.entitlements, поэтому переносим файл.
if [ -e AniLot/AniAnglia.entitlements ] && [ ! -e AniLot/AniLot.entitlements ]; then
  mv AniLot/AniAnglia.entitlements AniLot/AniLot.entitlements
fi
# Файлы ниже удаляем: их актуальные версии приходят в anilot-update.zip
# либо отсутствуют в проекте намеренно.
rm -f "AniLot.xcodeproj/xcshareddata/xcschemes/iOSAnixart.xcscheme"
rm -f  AniLot/Common/CollectionsTableViewController.h
rm -f  AniLot/Common/Releases/ReleaseHistoryTableViewCells.h
rm -rf AniLot/Assets.xcassets/artworks-LIXD0cMbsxr8Vcfy-6bPZfw-t500x500.imageset
