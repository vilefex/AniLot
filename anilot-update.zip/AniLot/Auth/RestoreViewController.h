//
//  RestoreViewController.h
//  AniLot
//
//  Created by Toilettrauma on 22.08.2024.
//

#import <UIKit/UIKit.h>

@interface RestoreViewController : UIViewController <UITextFieldDelegate>

@end
